<?php 
	// define( 'PATH', get_template_directory() ) ;
	// define( 'URI',  get_template_directory_uri() );
	 add_action( 'wp_enqueue_scripts', 'astra_child_enqueue_styles' );
	 function astra_child_enqueue_styles() {
 		  wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' ); 
 		  } 
		  echo get_template_directory();
		  //require_once get_template_directory() . '/inc/core-function.php';
 ?>