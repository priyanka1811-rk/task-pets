<?php 
	define( 'ASTRA_THEME_DIR', trailingslashit( get_template_directory() ) );
	define( 'ASTRA_THEME_URI', trailingslashit( esc_url( get_template_directory_uri() ) ) );
	 add_action( 'wp_enqueue_scripts', 'astra_child_enqueue_styles' );
	 function astra_child_enqueue_styles() {
 		  wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' ); 
 		  } 
		  
 ?>